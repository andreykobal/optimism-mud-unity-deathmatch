import pandas as pd
import chart_studio.plotly as py
import plotly.graph_objs as go
import glob
import os

def SearchFiles(word=""):
    files = []
    for file in glob.glob("*"):
        if word in file:
            files.append(file)
    return files

for csvFileName in SearchFiles(".csv"):
	htmlFileName = csvFileName.replace(".csv", ".html")
	if os.path.exists(htmlFileName):
		print("Skipping " + csvFileName + ", HTML file already exists...")
		continue
		
	df = pd.read_csv(csvFileName, comment='#')
	df.head()
	
	if df.columns[0] != "Frame":
		print("Skipping " + csvFileName + ", invalid format...")
		continue
		
	print("Generating HTML file for " + csvFileName)
	
	graphs = []
	
	for col in df.columns:
		if col == "Frame":
			continue
		graphs.append(go.Scatter(x=df["Frame"], y=df[col], mode="lines", name=col))

	layout = go.Layout(title=csvFileName, template="plotly_white")

	fig = go.Figure(data=graphs, layout=layout)
	fig.write_html(htmlFileName)
#	fig.show()

for logFileName in SearchFiles(".log"):
	htmlFileName = logFileName.replace(".log", ".html")
	if os.path.exists(htmlFileName):
		print("Skipping " + logFileName + ", HTML file already exists...")
		continue
		
	df = pd.read_csv(logFileName, comment='#')
	df.head()
	
	if df.columns[0] != "Frame":
		print("Skipping " + logFileName + ", invalid format...")
		continue
		
	print("Generating HTML file for " + logFileName)
	
	graphs = []
	
	for col in df.columns:
		if col == "Frame":
			continue
		graphs.append(go.Scatter(x=df["Frame"], y=df[col], mode="lines", name=col))

	layout = go.Layout(title=logFileName, template="plotly_white")

	fig = go.Figure(data=graphs, layout=layout)
	fig.write_html(htmlFileName)
#	fig.show()
