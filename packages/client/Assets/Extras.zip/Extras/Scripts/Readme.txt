These scripts generate browseable graphs (html + Plotly) from *.csv and *.log files. Frame/Time is expected in first column. Comment starts with '#'.
Python packages required: pandas, plotly, chart_studio
